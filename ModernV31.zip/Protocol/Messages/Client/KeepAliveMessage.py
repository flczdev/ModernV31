from ByteStream.Reader import Reader
from Protocol.Messages.Server.KeepAliveOkMessage import KeepAliveOkMessage
class KeepAliveMessage(Reader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        #self.db = db
        #online = 2

    def decode(self):
        pass

    def process(self, db):
        KeepAliveOkMessage(self.client, self.player).send()
        #self.db.update_player_account(self.player.token, 'Online', online)