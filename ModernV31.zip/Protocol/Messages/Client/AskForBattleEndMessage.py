from ByteStream.Reader import Reader
from Protocol.Messages.Server.BattleEndMessage import BattleEndMessage

class AskForBattleEndMessage(Reader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.players = {}

    def decode(self):
        self.result = self.readVInt()
        self.readVInt()
        self.rank = self.readVInt()
        self.readVInt()
        self.readVInt()
        self.readVInt()
        self.readVInt()
        self.readVInt()
        self.readVInt()
        self.readVInt()

        self.player.team = self.readVInt() #red or blue

        self.readVInt()

        self.readString() #Your Name

        self.readVInt()
        self.Bot1 = self.readVInt() #bot brawler
        self.readVInt()
        self.readVInt() #red or blue
        self.readVInt()

        self.Bot1N = self.readString()

        self.readVInt()
        self.Bot2 = self.readVInt() #bot brawler
        self.readVInt()
        self.readVInt() #red or blue
        self.readVInt()

        self.Bot2N = self.readString()

        self.readVInt()
        self.Bot3 = self.readVInt() #bot brawler
        self.readVInt()
        self.readVInt() #red or blue
        self.readVInt()

        self.Bot3N = self.readString()

        self.readVInt()
        self.Bot4 = self.readVInt() #bot brawler
        self.readVInt()
        self.readVInt() #red or blue
        self.readVInt()

        self.Bot4N = self.readString()

        self.readVInt()
        self.Bot5 = self.readVInt() #bot brawler
        self.readVInt()
        self.readVInt() #red or blue
        self.readVInt()

        self.Bot5N = self.readString()


    def process(self, db):
    	self.type = 0
    	
    	self.player.bot1_n = self.Bot1N
    	self.player.bot2_n = self.Bot2N
    	self.player.bot3_n = self.Bot3N
    	self.player.bot4_n = self.Bot4N
    	self.player.bot5_n = self.Bot5N
    	self.player.bot1 = self.Bot1
    	self.player.bot2 = self.Bot2
    	self.player.bot3 = self.Bot3
    	self.player.bot4 = self.Bot4
    	self.player.bot5 = self.Bot5
    	
    	BattleEndMessage(self.client, self.player, self.type, self.result, self.players, db).send()




