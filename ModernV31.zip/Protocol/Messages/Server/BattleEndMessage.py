from ByteStream.Writer import Writer

import random


class BattleEndMessage(Writer):

    def __init__(self, client, player, type, result, players, db):
        super().__init__(client)
        self.id = 23456
        self.player  = player
        self.type    = type
        self.result  = result
        self.players = players
        self.db = db

    def encode(self):
        
        brawler_trophies = self.player.brawlers_trophies[str(self.player.home_brawler)]
        brawler_high = self.player.brawlers_high_trophies[str(self.player.home_brawler)]
        torop = 0
        FinalReward = 0
        gainedtok = 0
        QuestTok = 0
        StarID = 0
        


        if 0 <= brawler_trophies <= 49:
            win_val = 8
            lose_val = 0

        else:
            if 50 <= brawler_trophies <= 99:
                win_val = 8
                lose_val = -1

            if 100 <= brawler_trophies <= 199:
                win_val = 8
                lose_val = -2

            if 200 <= brawler_trophies <= 299:
                win_val = 8
                lose_val = -3

            if 300 <= brawler_trophies <= 399:
                win_val = 8
                lose_val = -4

            if 400 <= brawler_trophies <= 499:
                win_val = 8
                lose_val = -5

            if 500 <= brawler_trophies <= 599:
                win_val = 8
                lose_val = -6

            if 600 <= brawler_trophies <= 699:
                win_val = 8
                lose_val = -7

            if 700 <= brawler_trophies <= 799:
                win_val = 8
                lose_val = -8

            if 800 <= brawler_trophies <= 899:
                win_val = 8
                lose_val = -9

            if 900 <= brawler_trophies <= 999:
                win_val = 8
                lose_val = -10

            if 1000 <= brawler_trophies <= 1099:
                win_val = 8
                lose_val = -11

            if 1100 <= brawler_trophies <= 1199:
                win_val = 8
                lose_val = -12

            if brawler_trophies >= 1200:
                win_val = 8
                lose_val = -12
                
            if 1 <= self.player.Streaks <= 2:
              win_val = 16
              lose_val = -0
              
            if 3 <= self.player.Streaks <= 4: 
              win_val = 24
              lose_val = -0
              
            if 5 <= self.player.Streaks <= 6:
              win_val = 32
              lose_val = -0
              
            if 10 <= self.player.Streaks <= 15:
              win_val = 45
              lose_val = -0
           
            if 15 <= self.player.Streaks <= 20:
              win_val = 55
              lose_val = -0
              
            if 20 <= self.player.Streaks <= 25:
              win_val = 65
              lose_val = -0
          
            if 25 <= self.player.Streaks <= 30:
              win_val = 75
              lose_val = -0
           
            if 30 <= self.player.Streaks <= 35:
              win_val = 85
              lose_val = -0
                

        if self.result == 0:
            trop = win_val
            self.player.trophies += trop
            self.player.tropanim = win_val
            self.player.exp_points += 20
            # 3v3
            self.player.threevthreewins += 1
            self.player.tropresult = win_val
            #Streaks
            self.player.Streaks += 1
            self.player.brawlers_trophies[str(self.player.home_brawler)] = brawler_trophies + win_val
            self.player.brawlers_high_trophies[str(self.player.home_brawler)] = brawler_trophies + win_val
            torop = win_val
            
            
            self.db.update_player_account(self.player.token, 'BrawlersTrophies', self.player.brawlers_trophies)
            self.db.update_player_account(self.player.token, 'Trophies', self.player.trophies)
            self.db.update_player_account(self.player.token, 'BrawlersHighestTrophies', self.player.brawlers_high_trophies)
            self.db.update_player_account(self.player.token, 'ExperiencePoints', self.player.exp_points)
            self.db.update_player_account(self.player.token, 'threevthreewins', self.player.threevthreewins)
            self.db.update_player_account(self.player.token, 'Streaks', self.player.Streaks)
            
            
        if self.result == 1:
            trop = lose_val
            self.player.trophies += trop
            self.player.tropresult = lose_val
            self.player.Streaks = 0
            self.player.brawlers_trophies[str(self.player.home_brawler)] = brawler_trophies + lose_val
            
            self.db.update_player_account(self.player.token, 'BrawlersTrophies', self.player.brawlers_trophies)
            self.db.update_player_account(self.player.token, 'Trophies', self.player.trophies)
            self.db.update_player_account(self.player.token, 'Streaks', self.player.Streaks)
            torop = 0
            
            
        tokendoubler = self.player.token_doubler
        gaindub = random.randint(0,30)
        gainedtok += random.randint(0,40)
        self.player.tkanim = gainedtok
        self.player.token_doubler -= gaindub
        if self.player.token_doubler == 0:
              tokendoubler = 0
              gaindub = 0
              self.db.update_player_account(self.player.token, 'TokenDoubler', - gaindub)
              self.db.update_player_account(self.player.token, 'Resources', gainedtok)
        self.writeVInt(self.type) # game mod
        self.writeVInt(self.result) # result
        self.writeVInt(gainedtok) # Tokens Gained
        self.writeVInt(self.player.tropresult) # Trophies Result
        
        
        self.writeVInt(0) # Unknown (Power Play Related)
        self.writeVInt(gaindub) # Doubled Tokens
        self.writeVInt(QuestTok) # Double Token Event
        self.writeVInt(tokendoubler) # Token Doubler Remaining
       
       
        self.writeVInt(0) # Big Game/Robo Rumble Time
        self.writeVInt(0) # Unknown (Championship Related)
        self.writeVInt(0) # Championship Level Passed
        self.writeVInt(0) # Challenge Reward Type (0 = Star Points, 1 = Star Tokens)
      
        
        self.writeVInt(0) # Challenge Reward Ammount
        self.writeVInt(0) # Championship Losses Left
        self.writeVInt(0) # Championship Maximun Losses
        self.writeVInt(0) # Coin Shower Event
        
        
        self.writeVInt(0) # Underdog Trophies
        self.writeVInt(16) # Battle Result Type
        self.writeVInt(-1) # Championship Challenge Type
        self.writeVInt(0) # Championship Cleared and Beta Quests

        self.writeVInt(6)
        
        self.writeVInt(1)
        self.writeVInt(16)
        self.writeVInt(self.player.home_brawler)
        self.writeVInt(29)
        self.writeVInt(self.player.selected_skins[str(self.player.home_brawler)])	
        self.writeVInt(self.player.brawlers_trophies[str(self.player.home_brawler)] - torop)
        self.writeVInt(0)
        self.writeVInt(self.player.brawlers_level[str(self.player.home_brawler)])
        self.writeVInt(0)
        self.writeString(self.player.name)
        self.writeVInt(100)
        self.writeVInt(28000000)
        self.writeVInt(43000000)
        self.writeVInt(0)
        
        
        self.writeVInt(0)
        self.writeVInt(16)
        self.writeVInt(self.player.bot1)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeString(f"{self.player.Streaks}")
        self.writeVInt(100)
        self.writeVInt(28000000)
        self.writeVInt(43000000)
        self.writeVInt(0)
        
        
        self.writeVInt(0)
        self.writeVInt(16)
        self.writeVInt(self.player.bot2)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeString(f"{self.player.Streaks}")
        self.writeVInt(100)
        self.writeVInt(28000000)
        self.writeVInt(43000000)
        self.writeVInt(0)
        
        
        self.writeVInt(2)
        self.writeVInt(16)
        self.writeVInt(self.player.bot3)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeString("Bot")
        self.writeVInt(100)
        self.writeVInt(28000000)
        self.writeVInt(43000000)
        self.writeVInt(0)
        
        
        self.writeVInt(2)
        self.writeVInt(16)
        self.writeVInt(self.player.bot4)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeString("Bot")
        self.writeVInt(100)
        self.writeVInt(28000000)
        self.writeVInt(43000000)
        self.writeVInt(0)
   
             
        self.writeVInt(2)
        self.writeVInt(16)
        self.writeVInt(self.player.bot5)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeString("Bot")
        self.writeVInt(100)
        self.writeVInt(28000000)
        self.writeVInt(43000000)
        self.writeNullVInt()


        # Experience Array
        self.writeVInt(2) # Count
        self.writeVInt(0) # Normal Experience ID
        self.writeVInt(20) # Normal Experience Gained
        self.writeVInt(8) # Star Player Experience ID
        self.writeVInt(0) # Star Player Experience Gained

        # Rank Up and Level Up Bonus Array
        self.writeVInt(0) # Count

        # Trophies and Experience Bars Array
        self.writeVInt(2) # Count
        self.writeVInt(1) # Trophies Bar Milestone ID
        self.writeVInt(self.player.brawlers_trophies[str(self.player.home_brawler)] - torop) # Brawler Trophies
        self.writeVInt(self.player.brawlers_high_trophies[str(self.player.home_brawler)] - torop) # Brawler Trophies for Rank
        self.writeVInt(5) # Experience Bar Milestone ID
        self.writeVInt(self.player.exp_points) # Player Experience
        self.writeVInt(self.player.exp_points) # Player Experience for Level

        self.writeDataReference(28, 0)# avatar
        self.writeBool(False)# play
        
        # Brawler Quests Todo: Mode Quests
        
        if self.player.home_brawler == self.player.questbrawler:
          questplus = 1
          self.player.questcurrgoal += questplus
          self.db.update_player_account(self.player.token, 'questcurrgoal', self.player.questcurrgoal)
        if self.player.questgoal <= self.player.questcurrgoal:
          questplus = 0
          QuestTok = self.player.questrw
          self.player.questcurrgoal += questplus
          self.db.update_player_account(self.player.token, 'questcurrgoal', self.player.questcurrgoal)
          self.player.resources[1]['Amount'] = self.player.resources[8]['Amount'] + self.player.questrw
          self.db.update_player_account(self.player.token, 'Resources', self.player.resources)