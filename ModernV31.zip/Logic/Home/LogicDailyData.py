from datetime import datetime
from Logic.Home.LogicShopData import LogicShopData

from DataBase.DBManager import DB

class LogicDailyData:

    def encode(self):

        time_stamp = int(datetime.timestamp(datetime.now()))

        self.writeVInt(time_stamp)
        self.writeVInt(time_stamp)

        self.writeVInt(self.player.trophies)
        self.writeVInt(self.player.high_trophies)
        self.writeVInt(self.player.high_trophies)

        self.writeVInt(self.player.trophy_reward)
        self.writeVInt(self.player.exp_points)

        self.writeDataReference(28, self.player.profile_icon)
        self.writeDataReference(43, self.player.name_color)

        self.writeVInt(50)
        for x in range(50):
            self.writeVInt(x)

        self.writeVInt(len(self.player.selected_skins))
        for x in self.player.selected_skins:
            self.writeDataReference(29, self.player.selected_skins[x])

        self.writeVInt(len(self.player.unlocked_skins))
        for x in self.player.unlocked_skins:
            self.writeDataReference(29, x)

        self.writeVInt(0)  # Unknown Array
        for x in range(0):
            self.writeDataReference(0,0)

        self.writeVInt(0)      # Leaderboard Global TID
        self.writeVInt(self.player.road)  # Trophy Road Reached Icon
        self.writeVInt(0)      # Unknown
        self.writeVInt(0)      # Unknown

        self.writeUInt8(0)     # Is Token Limit Reached

        self.writeVInt(self.player.token_doubler)
        self.writeVInt(99999)  # Trophy Road Timer
        self.writeVInt(0)      # Power Play Timer
        self.writeVInt(99999)  # Brawl Pass Timer

        self.writeVInt(0)  # Unknown

        self.writeBoolean(False)
        self.writeBoolean(False)

        self.writeUInt8(4) # Shop Token Doubler

        self.writeVInt(2) # Unknown
        self.writeVInt(2) # Unknown
        self.writeVInt(2) # Unknown

        self.writeVInt(0) # Name Change Cost
        self.writeVInt(0) # Name Change Timer

        LogicShopData.encodeShopOffers(self)

        self.writeVInt(0)  # AdStatus
        for x in range(0):
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(0)

        self.writeVInt(200) # Available Battle Tokens
        self.writeVInt(0)   # Time till Bonus Tokens

        self.writeVInt(0)  # Unknown Array
        for x in range(0):
            self.writeVInt(x)

        self.writeVInt(0)
        self.writeVInt(0)  # Unknown

        self.writeDataReference(16, self.player.home_brawler)

        self.writeString(self.player.region)
        self.writeString(self.player.content_creator)

        self.writeVInt(3)  # Anims
        self.writeInt(4)
        self.writeInt(self.player.tropanim)
        self.writeInt(3)
        self.writeInt(self.player.tkanim)
        self.writeInt(8)
        self.writeInt(self.player.staranim)

        self.writeVInt(0)  # CooldownEntry
        for x in range(0):
            self.writeVInt(0)
            self.writeDataReference(0, 0)
            self.writeVInt(0)

        self.writeVInt(1) # BrawlPassSeasonData
        for x in range(1):
            self.writeVInt(3)
            self.writeVInt(self.player.tokens )#токены
            self.writeUInt8(1)
            self.writeVInt(0)
            self.writeUInt8(0)

        self.writeVInt(1)  # ProLeagueSeasonData
        for x in range(1):
            self.writeVInt(1)
            self.writeVInt(9999)

        self.writeBoolean(True) # LogicQuests
        if True:
            self.writeVInt(1)
            for x in range(1):
                self.writeVInt(0)     # Unknown
                self.writeVInt(0)     # Unknown
                self.writeVInt(1)     # Mission Type
                self.writeVInt(self.player.questcurrgoal)     # Achieved Goal
                self.writeVInt(self.player.questgoal)     # Quest Goal
                self.writeVInt(self.player.questrw)    # Tokens Reward
                self.writeVInt(self.player.questcurrgoal)     # Unknown
                self.writeVInt(self.player.questlvl)     # Current level
                self.writeVInt(self.player.questlvl)     # Max level
                self.writeVInt(1)     # Quest Type
                self.writeUInt8(2)    # Quest State
                self.writeDataReference(16, self.player.questbrawler)
                self.writeVInt(self.player.questmode)     # GameMode
                self.writeVInt(0)     # Unknown
                self.writeVInt(0)     # Unknown

        # Emotes Array
        self.writeBoolean(True)
        if True:
            self.writeVInt(len(self.player.emotes_id))
            for x in self.player.emotes_id:
                self.writeDataReference(52, 0)
                self.writeVInt(1)     # Unknown
                self.writeVInt(1)     # Unknown
                self.writeVInt(1)     # Unknown

