from Core.Networking.Server import Server
from Utils.Helpers import Helpers

def main():

    Server("0.0.0.0", 9339).start()
                                                         
                                                         

if __name__ == '__main__':
    main()
